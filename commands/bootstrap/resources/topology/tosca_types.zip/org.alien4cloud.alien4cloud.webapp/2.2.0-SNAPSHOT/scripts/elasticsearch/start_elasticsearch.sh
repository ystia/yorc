#!/bin/bash -e
sudo /etc/init.d/elasticsearch start
