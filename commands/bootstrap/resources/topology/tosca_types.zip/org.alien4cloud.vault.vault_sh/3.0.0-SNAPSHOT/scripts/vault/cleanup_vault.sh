#!/bin/bash -e

echo "Cleaning up /etc/vault/"
sudo /bin/rm -Rf /etc/vault/*
